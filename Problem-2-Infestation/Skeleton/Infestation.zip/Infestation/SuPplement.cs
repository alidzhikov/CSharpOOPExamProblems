﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation
{
    class Supplement : ISupplement
    {
        public Supplement()
        {

        }
        public int AggressionEffect
        {
            get
            {
                throw new NotImplementedException();
            }
            private set
            {
                throw new NotImplementedException();
            }
        }

        public int HealthEffect
        {
            get
            {
                throw new NotImplementedException();
            }
            private set
            {
                throw new NotImplementedException();
            }
        }

        public int PowerEffect
        {
            get
            {
                throw new NotImplementedException();
            }
            private set
            {
                throw new NotImplementedException();
            }
        }

        public void ReactTo(ISupplement otherSupplement)
        {
            throw new NotImplementedException();
        }
    }
}
